BitMixList Media Kit

This kit contains press-ready BitMixList brand images.

Logos:
- logos/bitmixlist-logo-primary.png, .webp, .jpg
  Header logo, 525x158. Preferred for most placements.
- logos/bitmixlist-logo-banner.png, .webp, .jpg
  Primary/wide logo, 900x271. Use only for widescreen placements.

Icons:
- icons/bitmixlist-icon-32.png, .webp
- icons/bitmixlist-icon-180.png, .webp
- icons/bitmixlist-icon-192.png, .webp

Monochrome variants:
- Files ending in -black.png are solid black versions on transparent backgrounds.
- Files ending in -white.png are solid white versions on transparent backgrounds.

Usage notes:
- The header logo is preferred for most press use.
- Use the primary/wide logo only for widescreen layouts.
- Use PNG files when transparency is needed.
- Use white variants on dark backgrounds and black variants on light backgrounds.
- Keep the original proportions. Do not stretch, recolor, crop, or add effects.
